# Hogwarts Compass
Run: `node server.js` then open http://localhost:3000 (Node 16+, no npm install needed).

- `index.html`: your original frontend, unchanged
- `server.js`: backend (serves the page + API)
- `kb.js`: Hogwarts knowledge (places, houses, subjects, timetable, spells, creatures, objects, traditions)
- `data/`: saved judge scores and progress

API: `GET /api/health`, `POST /api/ask {q}`, `POST /api/scores`, `POST /api/progress`, `GET /api/scores`, `GET /api/kb`.
Open the page via the server, not by double-clicking the file, or it falls back to offline mode.
