// Hogwarts Compass backend: zero dependencies. Run: node server.js
const http = require('http'), fs = require('fs'), path = require('path');
const KB = require('./kb');
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, 'data');
fs.mkdirSync(DATA, {recursive: true});

const readJSON = (f, d) => { try { return JSON.parse(fs.readFileSync(path.join(DATA, f), 'utf8')); } catch { return d; } };
const writeJSON = (f, v) => { try { fs.writeFileSync(path.join(DATA, f), JSON.stringify(v, null, 2)); } catch {} };

const norm = s => String(s).toLowerCase().replace(/[^a-z0-9\s'-]/g, ' ').replace(/\s+/g, ' ').trim();
const has = (t, arr) => arr.some(k => t.includes(k));

function nextClass(now = new Date()) {
  const dow = now.getDay(), hr = now.getHours() + now.getMinutes() / 60;
  for (let add = 0; add < 7; add++) {
    const d = (dow + add) % 7, day = KB.timetable[d];
    if (!day) continue;
    const slot = day.find(s => add > 0 || s[0] >= hr);
    if (slot) {
      const names = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
      const when = add === 0 ? 'today' : add === 1 ? 'tomorrow' : 'on ' + names[d];
      return `Your next class is ${slot[1]} ${when} at ${slot[0] === 24 ? 'midnight' : slot[0] + ':00'}.`;
    }
  }
  return 'No lessons this weekend. Explore the castle instead!';
}
function findBy(obj, t, keyFn) {
  return Object.keys(obj).find(k => (keyFn ? keyFn(k, obj[k]) : t.includes(k)) && t.includes(keyFn ? '' : k)) || Object.keys(obj).find(k => t.includes(k));
}
function placeHit(t) {
  let best = null, score = 0;
  for (const p of Object.values(KB.places)) {
    const s = p.k.filter(k => t.includes(k)).length;
    if (s > score) { best = p; score = s; }
  }
  return best;
}
function houseText(h) {
  return `${h.icon} ${h.name} is known for ${h.values.toLowerCase()}. Founder: ${h.founder}. Colours: ${h.colours}. Mascot: ${h.animal}. Head: ${h.head}. Ghost: ${h.ghost}. Common room: ${h.common}. ${h.traditions}`;
}

function answer(q) {
  const t = norm(q);
  if (!t) return 'Ask me anything about Hogwarts: places, houses, subjects, spells or creatures.';
  if (/^(hi|hello|hey)\b/.test(t)) return 'Hello, young wizard! Ask me where a place is, about a House, a subject, a spell or a creature.';
  if (has(t, ['help', 'what can you'])) return 'Try: "Where is the Potions classroom?", "What class do I have next?", "What is Ravenclaw known for?", "Where can I find the library?" or "Tell me about hippogriffs".';
  if (has(t, ['next class', 'class do i have', 'next lesson', 'timetable', 'schedule']) && !has(t, ['where'])) {
    if (has(t, ['timetable', 'schedule', 'week'])) {
      const n = ['', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri'];
      return 'Weekly timetable: ' + Object.keys(KB.timetable).map(d => n[d] + ': ' + KB.timetable[d].map(s => s[1]).join(', ')).join(' | ') + '. ' + nextClass();
    }
    return nextClass();
  }
  if (has(t, ['daily routine', 'routine', 'day look', 'what time', 'curfew']))
    return 'A typical day: ' + KB.routine.map(r => r[0] + ':00 ' + r[1]).join('; ') + '.';
  // Houses
  for (const k in KB.houses) if (t.includes(k)) return houseText(KB.houses[k]);
  if (has(t, ['four houses', 'which house', 'houses'])) return 'The four Houses: ' + Object.values(KB.houses).map(h => h.icon + ' ' + h.name + ' (' + h.values.split(',')[0].toLowerCase() + ')').join(', ') + '.';
  // Spells
  for (const k in KB.spells) if (t.includes(k)) return '🪄 ' + k.replace(/\b\w/g, c => c.toUpperCase()) + ': ' + KB.spells[k];
  if (has(t, ['spell'])) return 'Beginner spells: ' + Object.keys(KB.spells).slice(0, 6).join(', ') + '. Ask about any of them.';
  // Creatures
  for (const k in KB.creatures) if (t.includes(k)) return '🐾 ' + k.replace(/\b\w/g, c => c.toUpperCase()) + ': ' + KB.creatures[k];
  if (has(t, ['creature', 'beast', 'magical creature'])) return 'Creatures I know: ' + Object.keys(KB.creatures).join(', ') + '. Name one and I will tell you about it.';
  // Objects
  for (const k in KB.objects) if (t.includes(k)) return '🔮 ' + k.replace(/\b\w/g, c => c.toUpperCase()) + ': ' + KB.objects[k];
  // Traditions
  for (const k in KB.traditions) if (t.includes(k)) return '🎉 ' + k.replace(/\b\w/g, c => c.toUpperCase()) + ': ' + KB.traditions[k];
  // Where questions or place hits beat subjects
  const p = placeHit(t);
  const wantsWhere = has(t, ['where', 'how do i', 'how to get', 'find', 'reach', 'directions', 'route', 'locate']);
  if (p && wantsWhere) return `📍 ${p.name} (${p.floor}). ${p.how} ${p.info}`;
  // Subjects
  for (const k in KB.subjects) if (t.includes(k) || t.includes(KB.subjects[k].name.toLowerCase())) {
    const s = KB.subjects[k];
    return `📚 ${s.name} with ${s.teacher} (${s.room}). Beginner tip: ${s.beginner} Good for ${s.for}.`;
  }
  if (has(t, ['subject', 'lessons', 'classes', 'interested', 'suggest', 'recommend']))
    return 'Subjects: ' + Object.values(KB.subjects).map(s => s.name).join(', ') + '. Like precision? Try Potions. Like action? Defence. Love plants? Herbology. Love stars? Astronomy.';
  if (has(t, ['professor', 'teacher', 'who teaches'])) {
    const s = Object.values(KB.subjects).find(s => t.includes(s.name.toLowerCase().split(' ')[0]));
    return s ? `${s.name} is taught by ${s.teacher}.` : 'Teachers: ' + Object.values(KB.subjects).map(s => s.name + ' (' + s.teacher + ')').join('; ') + '.';
  }
  if (p) return `📍 ${p.name} (${p.floor}). ${p.info} ${p.how}`;
  return 'The portraits are unsure. Try asking about a place, a House, a subject, a spell or a creature. Say "help" for ideas.';
}

// Persistence
let scores = readJSON('scores.json', []);
let progress = readJSON('progress.json', {});

const MIME = {'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.json':'application/json'};
function send(res, code, body, type = 'application/json') {
  res.writeHead(code, {'Content-Type': type, 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'});
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
function body(req) {
  return new Promise(r => { let d = ''; req.on('data', c => { d += c; if (d.length > 2e6) req.destroy(); }); req.on('end', () => { try { r(JSON.parse(d || '{}')); } catch { r({}); } }); });
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x'), p = url.pathname;
  if (req.method === 'OPTIONS') return send(res, 204, '');
  try {
    if (p === '/api/health') return send(res, 200, {ok: true, time: Date.now()});
    if (p === '/api/ask' && req.method === 'POST') { const b = await body(req); return send(res, 200, {answer: answer(String(b.q || '').slice(0, 300))}); }
    if (p === '/api/ask') return send(res, 200, {answer: answer((url.searchParams.get('q') || '').slice(0, 300))});
    if (p === '/api/scores' && req.method === 'POST') {
      const b = await body(req);
      const rec = {judge: String(b.judge || 'Anonymous').slice(0, 60), scores: Array.isArray(b.scores) ? b.scores.slice(0, 3).map(n => Math.min(10, Math.max(0, +n || 0))) : [], total: Math.min(10, Math.max(0, +b.total || 0)), at: new Date().toISOString()};
      scores.push(rec); writeJSON('scores.json', scores);
      return send(res, 200, {ok: true, count: scores.length, average: scores.reduce((a, s) => a + s.total, 0) / scores.length});
    }
    if (p === '/api/scores') return send(res, 200, {count: scores.length, average: scores.length ? scores.reduce((a, s) => a + s.total, 0) / scores.length : 0, scores});
    if (p === '/api/progress' && req.method === 'POST') { progress = await body(req); writeJSON('progress.json', progress); return send(res, 200, {ok: true}); }
    if (p === '/api/progress') return send(res, 200, progress);
    if (p === '/api/kb') return send(res, 200, KB);
    if (p === '/' || p === '/index.html') return send(res, 200, fs.readFileSync(path.join(__dirname, 'index.html')), MIME['.html']);
    return send(res, 404, {error: 'Not found'});
  } catch (e) { return send(res, 500, {error: 'Server error'}); }
}).listen(PORT, () => console.log('Hogwarts Compass running at http://localhost:' + PORT));
