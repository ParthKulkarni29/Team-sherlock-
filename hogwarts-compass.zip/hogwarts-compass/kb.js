// Knowledge base: locations, houses, subjects, timetable, encyclopedia
const places = {
  'great hall':{name:'Great Hall',floor:'Ground floor',how:'Go through the Entrance Hall and the double oak doors. All meals and feasts happen here.',info:'Four house tables under an enchanted ceiling that mirrors the sky, lit by floating candles.',who:'Headmaster Dumbledore',k:['great hall','hall','feast','dinner','breakfast','lunch']},
  'library':{name:'Library',floor:'First floor',how:'Climb the marble staircase to the first floor and turn left past the Defence corridor.',info:'Run by Madam Pince. Silence is strict. The Restricted Section needs a signed note from a professor.',who:'Madam Pince',k:['library','book','restricted','pince','study']},
  'potions':{name:'Potions Classroom',floor:'Dungeons',how:'Take the spiral stairs down from the Entrance Hall and follow the cold corridor.',info:'A chilly stone cellar with jars of specimens and cauldrons. Arrive on time.',who:'Professor Snape',k:['potion','snape','dungeon','cauldron']},
  'charms':{name:'Charms Classroom',floor:'Third floor',how:'Go up to the third floor and head west past the trophy room.',info:'Where first years learn Lumos and Wingardium Leviosa.',who:'Professor Flitwick',k:['charm','flitwick','wand','levitat']},
  'transfiguration':{name:'Transfiguration Classroom',floor:'Second floor',how:'Up the main staircase to the second floor, then follow the corridor on the right.',info:'Turning one thing into another. Starts with matches into needles.',who:'Professor McGonagall',k:['transfig','mcgonagall','transform']},
  'defence':{name:'Defence Against the Dark Arts Classroom',floor:'First floor',how:'First floor, the corridor just before the Library.',info:'Learn to protect yourself from dark creatures and curses.',who:'Defence professor',k:['defence','defense','dark arts','dada']},
  'astronomy':{name:'Astronomy Tower',floor:'Seventh floor',how:'Reach the seventh-floor corridor and climb the spiral staircase beside it.',info:'The tallest tower. Lessons run at midnight. Bring a warm cloak.',who:'Professor Sinistra',k:['astronom','tower','telescope','star']},
  'greenhouse':{name:'Greenhouse Three',floor:'Castle grounds',how:'Leave by the main doors and follow the lawn path past the herb gardens.',info:'Snapping, singing and screaming plants. Earmuffs provided.',who:'Professor Sprout',k:['greenhouse','herbology','plant','sprout','mandrake']},
  'quidditch':{name:'Quidditch Pitch',floor:'Castle grounds',how:'Out past the greenhouses and east across the grounds.',info:'Golden hoops and house stands. First years may not bring their own brooms.',who:'Madam Hooch',k:['quidditch','broom','flying','hooch','pitch']},
  'forest':{name:'Forbidden Forest',floor:'Castle grounds',how:'Walk past Hagrid\'s hut to the tree line, and stop there.',info:'Home to centaurs, unicorns and thestrals. Off limits without a supervisor.',who:'Hagrid',k:['forest','forbidden','hagrid','hut']},
  'owlery':{name:'Owlery',floor:'West tower, top',how:'Cross the courtyard and climb the west tower to the top.',info:'Hundreds of school owls for sending post.',who:'Resident owls',k:['owlery','owl','post','mail']},
  'hospital wing':{name:'Hospital Wing',floor:'First floor',how:'First floor, near the main staircase.',info:'Madam Pomfrey heals injuries, big and small.',who:'Madam Pomfrey',k:['hospital','infirmary','pomfrey','sick','hurt']},
  'kitchens':{name:'Kitchens',floor:'Basement',how:'Behind the painting of the fruit bowl, tickle the pear.',info:'The house-elves cook every meal. Hufflepuff common room is close.',who:'House-elves',k:['kitchen','food','hungry','pear']},
  'entrance hall':{name:'Entrance Hall',floor:'Ground floor',how:'Just inside the main front doors.',info:'Home of the four giant house-point hourglasses.',who:'Filch patrols it',k:['entrance','hourglass','house points']}
};
const houses = {
  gryffindor:{name:'Gryffindor',icon:'🦁',founder:'Godric Gryffindor',values:'Bravery, daring, nerve and chivalry',colours:'Scarlet and gold',animal:'Lion',element:'Fire',head:'Professor McGonagall',ghost:'Nearly Headless Nick',common:'Behind the Fat Lady portrait, seventh floor (Gryffindor Tower)',traditions:'Hosts the loudest Quidditch celebrations and welcomes newcomers with a feast.'},
  slytherin:{name:'Slytherin',icon:'🐍',founder:'Salazar Slytherin',values:'Ambition, cunning, resourcefulness and leadership',colours:'Green and silver',animal:'Serpent',element:'Water',head:'Professor Snape',ghost:'The Bloody Baron',common:'In the dungeons, beneath the Black Lake',traditions:'Fiercely proud; members look after each other and aim to win.'},
  ravenclaw:{name:'Ravenclaw',icon:'🦅',founder:'Rowena Ravenclaw',values:'Wit, learning, wisdom and creativity',colours:'Blue and bronze',animal:'Eagle',element:'Air',head:'Professor Flitwick',ghost:'The Grey Lady',common:'West tower, behind a door that asks a riddle instead of a password',traditions:'Late-night study sessions and riddle contests.'},
  hufflepuff:{name:'Hufflepuff',icon:'🦡',founder:'Helga Hufflepuff',values:'Loyalty, patience, hard work and fair play',colours:'Yellow and black',animal:'Badger',element:'Earth',head:'Professor Sprout',ghost:'The Fat Friar',common:'Near the kitchens, behind a stack of barrels',traditions:'Warm, welcoming and famous for treating everyone as family.'}
};
const subjects = {
  potions:{name:'Potions',teacher:'Professor Snape',room:'Dungeons',beginner:'Follow instructions exactly. Measure, stir and time everything.',for:'careful, patient people who like precision'},
  charms:{name:'Charms',teacher:'Professor Flitwick',room:'Third floor',beginner:'Wand movement and pronunciation matter. Start with Lumos and Wingardium Leviosa.',for:'creative people who enjoy practical magic'},
  transfiguration:{name:'Transfiguration',teacher:'Professor McGonagall',room:'Second floor',beginner:'Change one object into another. Concentration is everything.',for:'focused thinkers who like puzzles'},
  defence:{name:'Defence Against the Dark Arts',teacher:'Defence professor',room:'First floor',beginner:'Learn shields and stunning spells, and how to recognise dark creatures.',for:'brave, quick-reacting students'},
  herbology:{name:'Herbology',teacher:'Professor Sprout',room:'Greenhouses',beginner:'Wear dragon-hide gloves and earmuffs, and respect each plant.',for:'nature lovers and hands-on learners'},
  astronomy:{name:'Astronomy',teacher:'Professor Sinistra',room:'Astronomy Tower',beginner:'Chart stars and planets at midnight.',for:'curious, patient stargazers'},
  history:{name:'History of Magic',teacher:'Professor Binns (a ghost)',room:'First floor',beginner:'Long lectures on wizarding history. Take good notes.',for:'story lovers'},
  flying:{name:'Flying',teacher:'Madam Hooch',room:'Quidditch Pitch',beginner:'Hold your broom out and say "Up!" with confidence.',for:'adventurous students'}
};
// day 1=Mon..5=Fri; [startHour, subject]
const timetable = {
  1:[[9,'History of Magic'],[11,'Charms'],[14,'Potions']],
  2:[[9,'Transfiguration'],[11,'Herbology'],[14,'Flying']],
  3:[[9,'Defence Against the Dark Arts'],[11,'Charms'],[24,'Astronomy (midnight)']],
  4:[[9,'Potions'],[11,'Transfiguration'],[14,'Herbology']],
  5:[[9,'Charms'],[11,'Defence Against the Dark Arts'],[14,'History of Magic']]
};
const routine = [[7,'Wake up and dress in robes'],[8,'Breakfast, Great Hall'],[9,'Morning lessons'],[13,'Lunch'],[14,'Afternoon lessons'],[18,'Dinner, Great Hall'],[20,'Homework in the common room or Library'],[22,'Curfew: be in your common room']];
const spells = {
  lumos:'Creates light at your wand tip. Opposite: Nox.',
  nox:'Puts out the light made by Lumos.',
  'wingardium leviosa':'Makes objects float. Say it Wing-GAR-dium Levi-OH-sa.',
  alohomora:'Unlocks doors.',
  expelliarmus:'Disarms an opponent by flinging their wand away.',
  accio:'Summons an object to you.',
  expecto:'Expecto Patronum conjures a Patronus to fend off Dementors. Advanced magic.',
  reparo:'Mends broken objects.',
  stupefy:'Stunning spell.',
  incendio:'Creates fire.',
  protego:'Shield charm that blocks spells.',
  obliviate:'Erases memories. Strictly controlled.',
  riddikulus:'Turns a Boggart into something funny.'
};
const creatures = {
  hippogriff:'Half eagle, half horse. Bow first and wait for it to bow back. Buckbeak is the famous one.',
  unicorn:'Pure silver creature that lives in the Forbidden Forest. Their blood is cursed to take.',
  thestral:'Winged horse only visible to those who have seen death. Gentle despite its look.',
  dragon:'Huge fire-breathing creatures. Illegal to keep as pets.',
  boggart:'Shapeshifter that becomes your worst fear. Use Riddikulus.',
  phoenix:'Bird that bursts into flame and is reborn. Fawkes belongs to Dumbledore.',
  owl:'Used to deliver post. Hedwig is the best known.',
  centaur:'Half human, half horse, live in the Forest and read the stars.',
  basilisk:'Giant serpent whose gaze kills. Legend says one lives under the school.',
  niffler:'Furry creature drawn to shiny things.',
  mandrake:'Plant whose cry can knock you out. Always wear earmuffs.',
  dementor:'Dark creature that feeds on happiness. Only a Patronus drives it away.',
  troll:'Strong, slow and dim magical creature.',
  'house-elf':'Loyal magical servants who cook and clean at the school.',
  grindylow:'Small water demon in lakes. Snaps with long fingers.',
  kneazle:'Cat-like creature with a talent for spotting untrustworthy people.'
};
const objects = {
  wand:'Chosen by the wand: Ollivanders will match you to one.',
  'sorting hat':'Sits on your head and decides which house you belong in.',
  'time-turner':'Small hourglass used to travel back a few hours.',
  'marauder':'The Marauder\'s Map shows everyone in Hogwarts. "I solemnly swear that I am up to no good."',
  broom:'First years may fly school brooms only in lessons.',
  cloak:'An invisibility cloak hides the wearer completely.',
  portkey:'Object that teleports you when touched.',
  remembrall:'Glass ball that turns red when you have forgotten something.',
  pensieve:'Stone basin that stores and shows memories.',
  'golden snitch':'Tiny winged ball worth 150 points in Quidditch.'
};
const traditions = {
  quidditch:'Fast broom sport with seven players per team, three kinds of balls and a Golden Snitch.',
  'house cup':'Houses earn and lose points all year. The top house wins the Cup at the end-of-year feast.',
  sorting:'On arrival, the Sorting Hat places each first year in a house.',
  feast:'Start-of-term, Halloween and end-of-year feasts in the Great Hall.',
  'triwizard':'A famous inter-school tournament held at Hogwarts.',
  yule:'Christmas ball and winter feast.',
  halloween:'Pumpkins, floating candles and a huge feast.'
};
module.exports = {places,houses,subjects,timetable,routine,spells,creatures,objects,traditions};
